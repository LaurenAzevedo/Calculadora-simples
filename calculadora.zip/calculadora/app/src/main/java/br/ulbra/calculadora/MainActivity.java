package br.ulbra.calculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView edtResultado;
    Button btnSomar, btnMultiplicar, btnDividir, btnDiminuir;
    EditText edtNumero1, edtNumero2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtResultado = findViewById(R.id.edtResultado);
        btnSomar = findViewById(R.id.btnSomar);
        btnMultiplicar = findViewById(R.id.btnMultiplicar);
        btnDividir = findViewById(R.id.btnDividir);
        btnDividir = findViewById(R.id.btnDividir);
        btnDiminuir = findViewById(R.id.btnDiminuir);
        edtNumero1 = findViewById(R.id.edtNumero1);
        edtNumero2 = findViewById(R.id.edtNumero2);

        btnSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double n1, n2, result;
                n1= Double.parseDouble(edtNumero1.getText().toString());
                n2= Double.parseDouble(edtNumero2.getText().toString());
                result = n1 + n2;
                edtResultado.setText("O resultado é: "+ result);
            }
        });

        btnDiminuir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double n1, n2, result;
                n1= Double.parseDouble(edtNumero1.getText().toString());
                n2= Double.parseDouble(edtNumero2.getText().toString());
                result = n1 - n2;
                edtResultado.setText("O resultado é: "+ result);
            }
        });

        btnMultiplicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double n1, n2, result;
                n1= Double.parseDouble(edtNumero1.getText().toString());
                n2= Double.parseDouble(edtNumero2.getText().toString());
                result = n1 * n2;
                edtResultado.setText("O resultado é: "+ result);
            }
        });

        btnDividir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double n1, n2, result;
                n1= Double.parseDouble(edtNumero1.getText().toString());
                n2= Double.parseDouble(edtNumero2.getText().toString());
                result = n1 / n2;
                edtResultado.setText("O resultado é: "+ result);
            }
        });

        };
    }
